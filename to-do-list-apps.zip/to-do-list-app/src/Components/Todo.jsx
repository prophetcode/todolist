import React from 'react'

const Todo = () => {
  return (
    <div className='todo'>
        <p></p>
        <button>Edit</button>
        <button>Delete</button>

    </div>
  )
}

export default Todo