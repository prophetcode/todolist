import React from 'react'

const Header = ({headerTitle}) => {
  return (
    <div className='header'>
        {headerTitle}
    </div>
  )
}

export default Header