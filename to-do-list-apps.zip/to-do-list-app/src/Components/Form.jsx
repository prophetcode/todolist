import React from 'react'

const Form = () => {
  return (
    <form action="">
        <div className='inputWrapper'>
        <input type="text"  placeholder='Enter Todo.....'/>
        </div>
        <div>
            <button className='submit-btn'>Enter</button>
        </div>
    </form>
  )
}

export default Form