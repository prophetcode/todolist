import React from 'react'
import Todo from './Todo'
const Todos = () => {
    const todos =[
         {
            item:"I want to eat",
        },
        {
            item:"I want to dance",
        },
        {
            item:"I want to laugh",
        },
        {
            item:"I want to japa",
        }
        ];
  return (
        
    <div className='todosContainer'>
        
        {
           todos.map((item,index) =>(

               <Todo  key= {item} todo={item.item} />
           ))   
            
        }

    </div>
  )
}
export default Todos
