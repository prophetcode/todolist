import React from 'react'
import Header from './Components/Header'
import Form from './Components/Form'
import Todo from './Components/Todo'

const App = () => {
  return (
    <div className='container'>
<Header headerTitle="TO DO"/>
<main>
  <Form/>
<Todo/>
</main>
    </div>
  )
}

export default App